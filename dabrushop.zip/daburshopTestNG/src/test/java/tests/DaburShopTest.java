package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.CartPage;
import pages.FooterPage;
import pages.HomePage;
import pages.*;

public class DaburShopTest extends BaseTest {

	HomePage home;
	ProductPage product;
	CartPage cart;
	FooterPage footer;

	@Test(priority = 1)
	public void tc1_verifyHomePageUrl() {
		home = new HomePage(driver);

		String expectedUrl = "https://www.daburshop.com/";
		String actualUrl = home.getCurrentUrl();

		boolean urlMatch = actualUrl.equalsIgnoreCase(expectedUrl);
		System.out.println("TC1 - Homepage URL Match: " + (urlMatch ? "PASS" : "FAIL"));

		Assert.assertTrue(urlMatch, "Homepage URL mismatch. Expected: " + expectedUrl + " but got: " + actualUrl);
	}

	@Test(priority = 2)
	public void tc2_verifyLogoVisibility() {

		boolean result = home.isLogoVisible();
		System.out.println("TC2 - Logo Visibility: " + (result ? "PASS" : "FAIL"));
		Assert.assertTrue(result, "Logo is not visible.");
	}

	@Test(priority = 3)
	public void tc3_testSearchBarVisibility() throws InterruptedException {

		// Scroll to the search box
		home.toSearchInput();
		Thread.sleep(1000); // Optional, for visual confirmation

		// Assert it is visible
		boolean visible = home.isSearchInputVisible();
		System.out.println("TC3 - Search Input Visibility: " + (visible ? "PASS" : "FAIL"));
		Assert.assertTrue(visible, "Search input is not visible.");
	}

	@Test(priority = 4)
	public void tc4_verifySearchResultUrlAndBackToHome() {
		boolean clicked = home.searchForProduct("honey");
		Assert.assertTrue(clicked, "Search button click failed.");
		home.clickSearchButton();

		// :white_check_mark: Step 1: Verify URL contains search keyword
		boolean urlCheck = home.verifySearchResultUrl("honey");
		System.out.println("TC4 - Search Result URL contains 'honey': " + (urlCheck ? "PASS" : "FAIL"));
		Assert.assertTrue(urlCheck, "URL does not contain search keyword.");

		// :white_check_mark: Step 2: Click logo to go back to homepage
		boolean homeBack = home.clickLogoAndReturnToHome();
		System.out.println("TC4 - Back to Homepage by clicking logo: " + (homeBack ? "PASS" : "FAIL"));
		Assert.assertTrue(homeBack, "Did not return to homepage after clicking logo.");

	}

	@Test(priority = 5)
	public void tc5_verifyEmptyMobileValidation() throws InterruptedException {
	    boolean errorDisplayed = home.checkEmptyMobileValidation();
	    System.out.println("TC5 - Error displayed for empty mobile field: " + (errorDisplayed ? "PASS" : "FAIL"));
	    Assert.assertTrue(errorDisplayed, "TC5 - Error message not displayed for empty mobile input.");
	    
	    driver.navigate().back();
	    Thread.sleep(1200);
	}

	@Test(priority = 6)
	public void tc6_scrollMenuItems() throws InterruptedException {

		boolean result = home.scrollMenuRightAndLeft();
		System.out.println("TC6 - Menu Scroll Left/Right: " + (result ? "PASS" : "FAIL"));
		Assert.assertTrue(result, "Menu scroll action failed.");
	}

	@Test(priority = 7)
	public void tc7_hoverOnSaleAndAyurvedic() throws InterruptedException {

		boolean hoverSale = home.hoverOnSale();
		System.out.println("TC7 - Hover on 'Sale': " + (hoverSale ? "PASS" : "FAIL"));
		Assert.assertTrue(hoverSale, "Hover on 'Sale' card failed.");

		boolean hoverAyur = home.hoverOnAyurvedicWellness();
		System.out.println("TC7 - Hover on 'Ayurvedic Wellness': " + (hoverAyur ? "PASS" : "FAIL"));
		Assert.assertTrue(hoverAyur, "Hover on 'Ayurvedic Wellness' card failed.");
	}

	@Test(priority = 8)
	public void tc8_hoverOnComboBundle() throws InterruptedException {

		boolean result = home.hoverOnComboBundle();
		System.out.println("TC8 - Hover on 'Combo Bundle': " + (result ? "PASS" : "FAIL"));
		Assert.assertTrue(result, "Hover on 'Combo Bundle' card failed.");
	}

	@Test(priority = 9)
	public void tc9_testCarouselAutoChange() throws InterruptedException {
		boolean isChanging = home.isCarouselChanging();
		System.out.println("Carousel Auto Slide Test: " + (isChanging ? "PASS" : "FAIL"));
		Assert.assertTrue(isChanging, "TC( - Carousel did not auto-slide to next banner.");
	}

	@Test(priority = 10)
	public void tc10_testScrollToBestSellerAndClickSideButtons() {
		try {

			boolean leftClicked = home.clickLeftButton();
			System.out.println("TC10 - Left button click: " + (leftClicked ? "PASS" : "SKIPPED"));

			Thread.sleep(2000);

			boolean rightClicked = home.clickRightButtonTwice();
			System.out.println("TC10 - Right button click twice: " + (rightClicked ? "PASS" : "FAIL"));
			Thread.sleep(2000);

			Assert.assertTrue(rightClicked, "Right button not clickable.");
			boolean leftClick = home.clickLeftButton();
			Thread.sleep(2000);
			System.out.println("TC10 - Left button click: " + (leftClicked ? "PASS" : "SKIPPED"));

		} catch (Exception e) {
			System.out.println("TC9 - Error: " + e.getMessage());
			Assert.fail("TC10 - Exception occurred");
		}
	}

	@Test(priority = 11)
	public void tc11_testTabSwitchChangesBanner() {
		try {

			boolean bannerUpdated = home.clickTabsAndVerifyBanner();
			System.out.println("TC11 - Banner update after tab switch: " + (bannerUpdated ? "PASS" : "FAIL"));
			Assert.assertTrue(bannerUpdated, "Banner not updated properly");
		} catch (Exception e) {
			System.out.println("TC11 - Error: " + e.getMessage());
			Assert.fail("TC11 - Exception occurred");
		}
	}

	@Test(priority = 12)
	public void tc12_testViewAllRedirection() {
		try {
			boolean redirected = home.clickViewAllAndCheckURL();
			System.out.println("TC12 - View All redirection: " + (redirected ? "PASS" : "FAIL"));
			Assert.assertTrue(redirected, "View All did not redirect properly");
		} catch (Exception e) {
			e.printStackTrace(); // Print full stack trace
			System.out.println("TC12 - Error: " + e.getMessage());
			Assert.fail("TC12 - Exception occurred");
		}
	}

	@Test(priority = 13)
	public void tc_13_testBannerVisible() throws InterruptedException {
		product = new ProductPage(driver);
		Thread.sleep(1200);
		Assert.assertTrue(product.isBannerVisible(), "TC13 - Banner not visible");
		System.out.println("TC13 - Banner visibility: PASS");
	}

	@Test(priority = 14)
	public void tc14_testFilterDropdown() throws InterruptedException {
		home.scrollByPixels(0, 250);
		product.selectPriceHighToLow();
		System.out.println("TC14- Filter 'Price: high to low' selected: PASS");
	}

	@Test(priority = 15)
	public void tc15_testCategoryCheckbox() throws InterruptedException {
		product.selectCategoryCheckbox();
		Thread.sleep(1200);
		System.out.println("TC15- Category checkbox selected: PASS");
	}

	@Test(priority = 16)
	public void tc16_testProductDetailsAndTabs() throws InterruptedException {
		home.scrollByPixels(0, 500);
		product.openProductAndPrepare();
		product.verifyAllProductTabs();
		System.out.println("TC16 - Product detail, tabs and interactions: PASS");
	}

	@Test(priority = 17)
	public void TC17_testScrollType() throws InterruptedException {
		boolean isInfinite = product.isInfiniteScrollEnabled();
		Thread.sleep(1200);

		if (isInfinite) {
			System.out.println("TC17 - This page uses Infinite Scroll: PASS");
		} else {
			System.out.println("TC17 - This page uses Finite Scroll: PASS");
		}

	}

	@Test(priority = 18)
	public void TC18_testCartDrawerAndPage() throws InterruptedException {

		cart = new CartPage(driver);
		boolean drawerOpened = cart.openCartAndGoToCartPage();
		Assert.assertTrue(drawerOpened, "TC18 - Cart drawer did not open or View Cart click failed");

		boolean cartLoaded = cart.isCartPageLoaded();
		Assert.assertTrue(cartLoaded, "TC18 - Cart page did not load after View Cart");

		System.out.println("TC18 - Cart drawer opened and cart page loaded: PASS");
	}

	@Test(priority = 19)
	public void tc19_testMinusButtonDisabled() throws InterruptedException {
		boolean isDisabled = cart.isMinusButtonDisabled();
		if (isDisabled) {
			System.out.println("TC19 - Minus button disabled as expected: PASS");
		} else {
			System.out.println("TC19 - Minus button is clickable (unexpected): FAIL");
		}
		Assert.assertTrue(isDisabled, "TC19 - Minus button should be disabled at quantity 1");
	}

	@Test(priority = 20)
	public void tc20_increaseQuantity() throws InterruptedException {

		boolean result = cart.clickPlusButton();
		Assert.assertTrue(result, "TC20 - Quantity increase failed");
		System.out.println("TC20 PASS: Product quantity increased");
	}

	@Test(priority = 21)
	public void tc21_decreaseQuantity() throws InterruptedException {
		boolean result = cart.clickMinusButton();
		Assert.assertTrue(result, "TC21 - Quantity decrease failed");
		System.out.println("TC21 PASS: Product quantity decreased");
	}

	@Test(priority = 22)
	public void tc22_testRemoveItem() throws InterruptedException {
		boolean result = cart.removeItemFromCart();
		Assert.assertTrue(result, "TC22 - Item not removed from cart");
		System.out.println("TC22 - Item removed from cart: PASS");
	}

	@Test(priority = 23)
	public void tc23_testCheckoutButton() throws InterruptedException {
	    boolean clicked = cart.clickCheckoutIfVisible();
	    Assert.assertTrue(clicked, "TC23 - Checkout button not visible or not clickable");
	    System.out.println("TC23 - Checkout button clicked: " + (clicked ? "PASS" : "FAIL"));
	}
	@Test(priority = 24)
	public void tc24_checkFooterLinks() throws InterruptedException {
             footer = new FooterPage(driver);
	   footer.testPopularCategoryLinks();  
	}
	@Test(priority = 25)
	public void tc25_checkFooterLogo() throws InterruptedException {
	    boolean logoOk = footer.isFooterLogoVisibleAndLoaded();
	    Assert.assertTrue(logoOk, "TC25 - Footer logo not visible or not loaded correctly.");
	    System.out.println("TC25 - Footer logo test: PASS");
	}

}