package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.util.List;

public class CartPage {
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
//locators
	By cartPageIdentifier = By.xpath("//h1[contains(text(),'Your cart') or contains(text(),'Shopping Cart')]");

	By disabledMinusButton = By.xpath("//button[@name='minus' and contains(@class,'disabled')]");
	By individualPrice = By.xpath("(//span[@class='price price--end'])[1]");
	By totalPrice = By.xpath("//p[contains(@class,'totals__total-value')]");
	By removeButton = By.xpath("//a[contains(@class,'button--tertiary') and contains(text(),'Remove')]");
	By checkoutButton = By.xpath("//button[@type='button' and contains(.,'Checkout')]");
	  // LOCATORS
    private By plusButton = By.xpath("//*[@id='CartItem-1']//button[2]");
    private By minusButton = By.xpath("//*[@id='CartItem-1']//button[1]");


	// 🔢 Quantity input field
	By quantityValue = By.xpath("//input[contains(@class, 'quantity__input') and @type='number']");


	By cartIcon = By.cssSelector("svg.icon-cart");

	By cartDrawer = By.id("CartDrawer");

	By viewCartButton = By.id("CartDrawer-viewcart");
	 public CartPage(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	        this.js = (JavascriptExecutor) driver;
	    }

	// - Scroll up and click cart icon
	public void openCart() throws InterruptedException {

		Thread.sleep(800);
		WebElement cart = wait.until(ExpectedConditions.elementToBeClickable(cartDrawer));
		cart.click();
		Thread.sleep(1200);
	}

	// Verify cart page is opened correctly
	public boolean isCartPageLoaded() throws InterruptedException {
		Thread.sleep(1200);
		return driver.findElements(cartPageIdentifier).size() > 0;
	}

	// Quantity minus button check (initially disabled)
	public boolean isMinusButtonDisabled() throws InterruptedException {
		Thread.sleep(1200);
		return driver.findElements(disabledMinusButton).size() > 0;
	}

	 // METHOD TO INCREASE QUANTITY
    public boolean clickPlusButton() {
        try {
            WebElement plusBtn = wait.until(ExpectedConditions.elementToBeClickable(plusButton));
           
            plusBtn.click();
            Thread.sleep(1200);
            return true;
        } catch (Exception e) {
            System.out.println("TC21 - Error clicking plus button: " + e.getMessage());
            return false;
        }
    }

    // METHOD TO DECREASE QUANTITY
    public boolean clickMinusButton() {
        try {
            WebElement minusBtn = wait.until(ExpectedConditions.elementToBeClickable(minusButton));
            
            minusBtn.click();
            Thread.sleep(1500);
            return true;
        } catch (Exception e) {
            System.out.println("TC22 - Error clicking minus button: " + e.getMessage());
            return false;
        }
    }



	public boolean removeItemFromCart() {
	    try {
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

	        // Locate the remove <a> tag using aria-label instead (more reliable)
	        WebElement removeBtn = wait.until(ExpectedConditions.elementToBeClickable(
	            By.xpath("//a[contains(@aria-label,'Remove')]")));

	 
	        removeBtn.click();

			
	        Thread.sleep(2000);  
			return true;
	        

	    } catch (Exception e) {
	        System.out.println("TC23 - Error removing item: " + e.getMessage());
	        return false;
	    }
	}


	// METHOD: TC24 - Check if checkout button is visible and clickable
	public boolean clickCheckoutIfVisible() {
	    try {
	        WebElement checkoutBtn = wait.until(ExpectedConditions.presenceOfElementLocated(checkoutButton));

	        if (checkoutBtn.isDisplayed() && checkoutBtn.isEnabled()) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", checkoutBtn);
	            Thread.sleep(800);
	            checkoutBtn.click();
	            return true;
	        } else {
	            System.out.println("TC23 - Checkout button is not visible or not enabled.");
	            return false;
	        }

	    } catch (TimeoutException e) {
	        System.out.println("TC23 - Checkout button not found on page.");
	        return false;
	    } catch (Exception e) {
	        System.out.println("TC23 - Unexpected error while clicking Checkout: " + e.getMessage());
	        return false;
	    }
	}

	// Combined method
	public boolean openCartAndGoToCartPage() {
	    try {
	        js.executeScript("window.scrollTo(0, 0);");
	        Thread.sleep(1200);

	        WebElement cartBtn = wait.until(ExpectedConditions.elementToBeClickable(cartIcon));
	        cartBtn.click();
	        Thread.sleep(1200);

	        WebElement drawer = wait.until(ExpectedConditions.visibilityOfElementLocated(cartDrawer));
	        if (!drawer.isDisplayed()) {
	            System.out.println("TC18 - Cart drawer not visible");
	            return false;
	        }

	        WebElement viewCart = wait.until(ExpectedConditions.elementToBeClickable(viewCartButton));
	        viewCart.click();
	        Thread.sleep(1200);

	        return true;
	    } catch (Exception e) {
	        System.out.println("TC18 - Exception in opening cart drawer or view cart: " + e.getMessage());
	        return false;
	    }
	}

}
