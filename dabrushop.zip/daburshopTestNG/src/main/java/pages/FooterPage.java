package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.util.List;

public class FooterPage {
    WebDriver driver;
    WebDriverWait wait;

    // === Locators ===
    By footer = By.tagName("footer");
   
    By footerLogo = By.xpath("//img[contains(@src,'d-footer-logo')]");
    By shilajitLink = By.xpath("//a[normalize-space()='Shilajit']");
    By aboutUsLink = By.xpath("//a[normalize-space()='About Us']");
    By contactUsLink = By.xpath("//a[normalize-space()='Contact Us']");

    public FooterPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    // === Methods ===
    public void scrollToFooter() {
        WebElement footerElement = wait.until(ExpectedConditions.presenceOfElementLocated(footer));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", footerElement);
    }

    public boolean isFooterLogoVisibleAndLoaded() {
        try {
            WebElement logo = wait.until(ExpectedConditions.visibilityOfElementLocated(footerLogo));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", logo);
            Thread.sleep(800);

            boolean isDisplayed = logo.isDisplayed();
            boolean isLoaded = (Boolean) ((JavascriptExecutor) driver).executeScript(
                "return arguments[0].complete && typeof arguments[0].naturalWidth != 'undefined' && arguments[0].naturalWidth > 0", logo
            );

            System.out.println("TC25 - Logo displayed: " + isDisplayed);
            System.out.println("TC25 - Logo loaded correctly: " + isLoaded);

            return isDisplayed && isLoaded;

        } catch (Exception e) {
            System.out.println("TC25 - Exception checking footer logo: " + e.getMessage());
            return false;
        }
    }
    public void testPopularCategoryLinks() throws InterruptedException {
        // 1. Click Shilajit
        WebElement shilajit = wait.until(ExpectedConditions.elementToBeClickable(shilajitLink));
        shilajit.click();
        Thread.sleep(1200);
        System.out.println("TC24 - Shilajit page opened: PASS");

        // 2. Click About Us and go back
        WebElement aboutUs = wait.until(ExpectedConditions.elementToBeClickable(aboutUsLink));
        aboutUs.click();
        Thread.sleep(1200);
        System.out.println("TC24 - About Us page opened");
        driver.navigate().back();
        Thread.sleep(1200);

        // 3. Click Contact Us and go back
        WebElement contactUs = wait.until(ExpectedConditions.elementToBeClickable(contactUsLink));
        contactUs.click();
        Thread.sleep(1200);
        System.out.println("TC24 - Contact Us page opened");
        driver.navigate().back();
        Thread.sleep(1200);
    }
}
    

