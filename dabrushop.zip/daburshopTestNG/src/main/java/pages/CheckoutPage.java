package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;

public class CheckoutPage {
    WebDriver driver;
    WebDriverWait wait;

    // === Locators ===
    By checkoutButton = By.xpath("//button[@name='checkout']");
    By checkoutHeader = By.xpath("//h1[contains(text(),'Customer information')]");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(12));
    }

    // === Methods ===
    public void proceedToCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
    }

    public boolean isOnCheckoutPage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(checkoutHeader)).isDisplayed();
    }
}
