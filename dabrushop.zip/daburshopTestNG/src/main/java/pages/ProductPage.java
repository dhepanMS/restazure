package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.util.List;

public class ProductPage {
    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;
    HomePage home;

    // ---------- Locators ----------
    By viewAllButton = By.xpath("//a[@href='/collections/all-dabur-products']//i[@class='fa-solid fa-arrow-right']");
    By bannerImage = By.xpath("//div[@class='banner-main']//img[contains(@class, 'collection-banner-image')]");
    By filterDropdown = By.id("SortBy");
    By priceHighToLow = By.xpath("//*[@id='SortBy']/option[text()='Price, high to low']");
    By categoryCheckbox = By.xpath("//label[@for='Filter-filter.p.t.category-1']//*[name()='svg']");

    By firstProduct = By.xpath("//a[@id='CardLink-template--17816896405635__product-grid-8603639677059']");
    By addToCartButton = By.xpath("//button[contains(text(),'Claim Offer')]");
    By closeCartButton = By.xpath("//button[contains(@class,'drawer__close')]");
    
    By productDetailsTab = By.xpath("//h6[text()='Product Details']");
    By viewMore = By.xpath("//div[@class='show-more']");
    By importantInfo = By.xpath("//h6[text()='Important Information']");
    By ratingsAndReviews = By.xpath("//h6[text()='Ratings and reviews']");
    By faqTab = By.xpath("//h6[text()='FAQ’s']");
    By faqQuestion = By.xpath("//h3[contains(text(),'How do I place an order on Dabur Shop?')]");
    By additionalInfo = By.xpath("//h6[text()='Additional Information']");

    By infiniteScrollItems = By.xpath("//div[@id='ProductGridContainer']//div[contains(@class,'grid__item')]");

    By cartIcon = By.xpath("//svg[@class='icon icon-cart']");
    By cartDrawer = By.cssSelector("cart-drawer"); // or "#CartDrawer"
    By viewCartButton = By.xpath("//a[contains(@href, '/cart') and contains(text(), 'View cart')]");
    // ---------- Constructor ----------
    public ProductPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        js = (JavascriptExecutor) driver;
    }

    // ---------- Methods ----------

   

    public boolean isCorrectPageLoaded(String expectedURL) {
        return driver.getCurrentUrl().contains(expectedURL);
    }

    public boolean isBannerVisible() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(bannerImage)).isDisplayed();
    }

    public void selectPriceHighToLow() throws InterruptedException {
        WebElement dropdownElement = wait.until(ExpectedConditions.elementToBeClickable(filterDropdown));
        Select dropdown = new Select(dropdownElement);

        // Step 1: Get product count before filter
        int beforeCount = driver.findElements(infiniteScrollItems).size();

        // Step 2: Select dropdown option
        dropdown.selectByVisibleText("Price, high to low");
        Thread.sleep(1200); // Wait for UI update

        // Step 3: Get product count after selection
        int afterCount = driver.findElements(infiniteScrollItems).size();

        // Step 4: Check if content changed
        if (afterCount == beforeCount) {
            System.out.println("Warning: Page might not have updated after selecting filter. Retrying...");

            // Retry once
            dropdown.selectByVisibleText("Price, high to low");
            Thread.sleep(1200); // retry wait

            // Recheck product count
            int afterRetryCount = driver.findElements(infiniteScrollItems).size();

            if (afterRetryCount == beforeCount) {
                System.out.println("Retry failed. Reloading page...");
                driver.navigate().refresh();
                Thread.sleep(2000); // wait after reload
            } else {
                System.out.println("Filter applied successfully on retry.");
            }
        } else {
            System.out.println("Filter applied and page updated successfully.");
        }
    }



    public void selectCategoryCheckbox() {
        try {
            WebElement checkbox = wait.until(ExpectedConditions.presenceOfElementLocated(categoryCheckbox));
            
            home.scrollByPixels(0, 180);
            Thread.sleep(800);

            // Try clicking
            wait.until(ExpectedConditions.elementToBeClickable(checkbox)).click();
            System.out.println("Checkbox clicked normally.");

        } catch (Exception e) {
            System.out.println("Initial click failed. Refreshing page and retrying...");

            // Refresh the page and retry
            driver.navigate().refresh();
            try {
                Thread.sleep(1500); // wait for reload

                WebElement checkbox = wait.until(ExpectedConditions.presenceOfElementLocated(categoryCheckbox));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", checkbox);
                Thread.sleep(800);
                wait.until(ExpectedConditions.elementToBeClickable(checkbox)).click();

                System.out.println("Checkbox clicked successfully after refresh.");

            } catch (Exception ex) {
                System.out.println("Checkbox still failed after refresh: " + ex.getMessage());
            }
        }
    }



 

    public void openProductAndPrepare() throws InterruptedException {
        WebElement productLink = wait.until(ExpectedConditions.elementToBeClickable(firstProduct));
        productLink.click();
        Thread.sleep(1200);

        WebElement addToCart = wait.until(ExpectedConditions.elementToBeClickable(addToCartButton));
        addToCart.click();
        Thread.sleep(1200);

        WebElement closeDrawer = wait.until(ExpectedConditions.elementToBeClickable(closeCartButton));
        closeDrawer.click();
        Thread.sleep(1200);

    }
    


    public void verifyAllProductTabs() throws InterruptedException {
       
        Thread.sleep(1200);

        // Product Details Tab
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h6[contains(text(),'Product Details')]"))).click();
        Thread.sleep(1200);

        // View More
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div.show-more"))).click();
        Thread.sleep(1200);

        // Important Information Tab
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h6[contains(text(),'Important Information')]"))).click();
        Thread.sleep(1200);

        // Ratings and Reviews Tab
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h6[contains(text(),'Ratings and reviews')]"))).click();
        Thread.sleep(1200);

        // FAQ Tab
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h6[contains(text(),'FAQ’s')]"))).click();
        Thread.sleep(1200);

        // FAQ Question
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h3[contains(text(),'How do I place an order')]"))).click();
        Thread.sleep(1200);

        // Additional Information Tab
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h6[contains(text(),'Additional Information')]"))).click();
        Thread.sleep(1200);
    }

    public boolean isInfiniteScrollEnabled() {
        int initialCount = driver.findElements(infiniteScrollItems).size();
        int scrollAttempts = 4;

        for (int i = 0; i < scrollAttempts; i++) {
            js.executeScript("window.scrollBy(0, document.body.scrollHeight)");
            try {
                Thread.sleep(2000); // wait for loading
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            int newCount = driver.findElements(infiniteScrollItems).size();
            if (newCount > initialCount) {
                System.out.println("Infinite scroll detected: More items loaded.");
                return true;
            }
        }

        System.out.println("Finite scroll detected: No new items loaded.");
        return false;
    }
    public boolean scrollUpAndOpenCart() {
        try {
            js.executeScript("window.scrollTo(0, 0);");
            Thread.sleep(1200);

            WebElement cartBtn = wait.until(ExpectedConditions.elementToBeClickable(cartIcon));
            cartBtn.click();
            Thread.sleep(1200);

            // Verify cart drawer is open
            WebElement drawer = wait.until(ExpectedConditions.visibilityOfElementLocated(cartDrawer));
            return drawer.isDisplayed();
        } catch (Exception e) {
            System.out.println("TC18 - Cart drawer did not open properly: " + e.getMessage());
            return false;
        }
    }
}
