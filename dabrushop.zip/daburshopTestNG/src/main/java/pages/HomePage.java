package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.util.List;

public class HomePage {

	WebDriver driver;
	WebDriverWait wait;
	Actions actions;
	 HomePage home;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		this.actions = new Actions(driver);
	}

	// === Locators ===

	By logo = By.xpath("//img[@alt='Daburshop']");

	By menuContainer = By.cssSelector(".menu-scroll-container");
	By menuCards = By.cssSelector(".menu-card-wrapper");
	 // Locators
        By mobileInput = By.xpath("//input[@id='mobile']");
   

    By loginIcon = By.xpath("//div[@class='in-icon-main']//account-icon//*[name()='svg']");
    By sendOtpButton = By.id("send_otp");
    By errorMessage = By.xpath("//div[@id='message' and contains(text(),'10-digit')]");

	By searchInput = By.xpath("//input[@class='_input_z49kb_35 rps-csb-input']");

	By searchButton = By.xpath("//button[@title='Search']//*[name()='svg']");
	

	By cartIcon = By.cssSelector("a[href='/cart']");

	By saleCard = By.xpath("//p[text()='Sale']/ancestor::a");
	By ayurvedicCard = By.xpath("//p[contains(text(),'Ayurvedic')]/ancestor::a");
	By comboBundleCard = By.xpath("//p[contains(text(),'Combo Bundle')]/ancestor::a");
	// Locators for TC8 - Scroll & Side Buttons
	By bestSellerSection = By.xpath("//h2[contains(text(),'Bestseller')]");
	By leftButton = By.xpath("//ul[@class='tbs-slider slick-initialized slick-slider']//button[@aria-label='Previous'][normalize-space()='Previous']");
	By rightButton = By.xpath("//ul[@class='tbs-slider slick-initialized slick-slider']//button[@aria-label='Next'][normalize-space()='Next']");

	// Locators for TC9 - Tabs and Banner
	By ayurvedicTab = By.xpath("//li[@role='tab']//p[contains(text(),'Ayurvedic Wellness')]");
	By healthFoodTab = By.xpath("//li[@role='tab']//p[contains(text(),'Health Food & Drinks')]");
	By banner = By.cssSelector("#tabbed-best-sellers-template--17816896667779__bestseller_mWxkWy > div");

	// Locator for TC10 - View All redirection

	public By allproduct = By.xpath("//div[@id='shopify-section-sections--17816896929923__custom_navigation_7NQMAh']//a[@title='All Products'][normalize-space()='All Products']");

	// === Actions ===

	public String getCurrentUrl() {
		return driver.getCurrentUrl();
	}

	public boolean isLogoVisible() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(logo)).isDisplayed();
	}

	public boolean isSearchInputVisible() {
		try {
			WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(searchInput));
			return input.isDisplayed();
		} catch (Exception e) {
			System.out.println("Search input not visible: " + e.getMessage());
			return false;
		}
	}

	public void toSearchInput() {
		try {
			WebElement input = wait.until(ExpectedConditions.presenceOfElementLocated(searchInput));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", input);
		} catch (Exception e) {
			System.out.println("Scrolling to search input failed: " + e.getMessage());
		}
	}

	public boolean checkEmptyMobileValidation() {
	    try {
	        

	        wait.until(ExpectedConditions.elementToBeClickable(loginIcon)).click();
	        System.out.println("TC5 - Clicked login icon.");

	        wait.until(ExpectedConditions.elementToBeClickable(sendOtpButton)).click();
	        System.out.println("TC5 - Clicked send OTP button.");

	        // wait up to, say, 5 seconds for the error message
	        WebElement error = new WebDriverWait(driver, Duration.ofSeconds(10))
	                .until(ExpectedConditions.visibilityOfElementLocated(errorMessage));

	        boolean displayed = error.isDisplayed();
	        System.out.println("TC5 - Error element found, displayed: " + displayed);
	        return displayed;
	    } catch (TimeoutException te) {
	        System.out.println("TC5 - Timeout waiting for error message: " + te.getMessage());
	        return false;
	    } catch (Exception e) {
	        System.out.println("TC5 - Exception in empty mobile validation: ");
	        e.printStackTrace();
	        return false;
	    }
	}



	public boolean searchForProduct(String productName) {
		try {
			WebElement input = wait.until(ExpectedConditions.presenceOfElementLocated(searchInput));
			//((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", input);
			input.clear();
			input.sendKeys(productName);
			Thread.sleep(1200);
			return input.getAttribute("value").contains(productName);
			
		} catch (Exception e) {
			System.out.println("Search typing failed: " + e.getMessage());
			return false;
		}
	}
	public boolean clickSearchButton() {
	    try {
	        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(searchButton));
	        button.click();
	        Thread.sleep(2000); // optional wait for page load
	        return true;
	    } catch (Exception e) {
	        System.out.println("Search button click failed: " + e.getMessage());
	        return false;
	    }
	}
	public boolean verifySearchResultUrl(String keyword) {
	    try {
	        String currentUrl = driver.getCurrentUrl();
	        return currentUrl.contains("search?q=" + keyword);
	    } catch (Exception e) {
	        System.out.println("Search result URL check failed: " + e.getMessage());
	        return false;
	    }
	}

	public boolean clickLogoAndReturnToHome() {
	    try {
	        WebElement logo = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[@alt='Daburshop']")));
	        logo.click();
	        wait.until(ExpectedConditions.urlToBe("https://www.daburshop.com/"));
	        return driver.getCurrentUrl().equalsIgnoreCase("https://www.daburshop.com/");
	    } catch (Exception e) {
	        System.out.println("Clicking logo to return to homepage failed: " + e.getMessage());
	        return false;
	    }
	}
	 public String getCurrentCarouselImageSrc() {
	        WebElement activeSlide = wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.cssSelector(".slick-slide.slick-active.slick-center picture.desktop-image-wrapper img")));
	        return activeSlide.getAttribute("src");
	    }

	    public boolean isCarouselChanging() throws InterruptedException {
	        String firstImage = getCurrentCarouselImageSrc();
	        Thread.sleep(5000); // wait for auto-slide
	        String secondImage = getCurrentCarouselImageSrc();

	        return !firstImage.equals(secondImage);
	    }


	public boolean isLoginIconVisible() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(loginIcon)).isDisplayed();
	}

	public boolean isCartIconVisible() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(cartIcon)).isDisplayed();
	}

	public boolean scrollMenuRightAndLeft() throws InterruptedException {
		Thread.sleep(1200);
		WebElement container = wait.until(ExpectedConditions.visibilityOfElementLocated(menuContainer));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft += 500;", container);
		Thread.sleep(600);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft -= 500;", container);
		Thread.sleep(600);
		return container.isDisplayed();
	}

	public boolean hoverOnSale() throws InterruptedException {
		WebElement sale = wait.until(ExpectedConditions.visibilityOfElementLocated(saleCard));
		actions.moveToElement(sale).perform();
		Thread.sleep(800);
		return sale.isDisplayed();
	}

	public boolean hoverOnAyurvedicWellness() throws InterruptedException {
		WebElement ayur = wait.until(ExpectedConditions.visibilityOfElementLocated(ayurvedicCard));
		actions.moveToElement(ayur).perform();
		Thread.sleep(800);
		return ayur.isDisplayed();
	}
	public void scrollByPixels(int x, int y) {
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(arguments[0], arguments[1]);", x, y);
	}
	

	public boolean clickLeftButton() throws InterruptedException {
		
	    WebElement leftBtn = driver.findElement(leftButton);

	    // Left button is usually disabled at start, so we check that case.
	    if (leftBtn.isDisplayed()) {
	        if (leftBtn.isEnabled()) {
	            leftBtn.click();
	            Thread.sleep(2000);
	            System.out.println("Left button is clickable - clicked.");
	            return true;
	        } else {
	            System.out.println("Left button is disabled - already at start.");
	            return false;  // Not a failure, just no action needed
	        }
	    } else {
	        System.out.println("Left button is not visible.");
	        return false;
	    }
	}


	public boolean clickRightButtonTwice() throws InterruptedException {
	    WebElement rightBtn = driver.findElement(rightButton);
	    if (rightBtn.isDisplayed() && rightBtn.isEnabled()) {
	        rightBtn.click();
	        Thread.sleep(2000);
	        rightBtn.click();
	        return true;
	    }
	    return false;
	}

	public boolean clickTabsAndVerifyBanner() throws InterruptedException {
	    driver.findElement(ayurvedicTab).click();
	    Thread.sleep(2000);
	    WebElement bannerElement = driver.findElement(banner);
	    if (!bannerElement.isDisplayed()) return false;

	    driver.findElement(healthFoodTab).click();
	    Thread.sleep(2000);
	    return bannerElement.isDisplayed();
	}

	public boolean clickViewAllAndCheckURL() throws InterruptedException {
	    try {
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        WebElement allproducts = wait.until(ExpectedConditions.elementToBeClickable(allproduct));
	        allproducts.click();
	        Thread.sleep(1200); // Let the page load
	        String currentUrl = driver.getCurrentUrl();
	        return currentUrl.contains("/collections/all-dabur-products");
	    } catch (Exception e) {
	        System.out.println("Error in clickViewAllAndCheckURL: " + e.getMessage());
	        return false;
	    }
	}

	public boolean hoverOnComboBundle() throws InterruptedException {
		WebElement combo = wait.until(ExpectedConditions.visibilityOfElementLocated(comboBundleCard));
		actions.moveToElement(combo).perform();
		Thread.sleep(800);
		return combo.isDisplayed();
	}
	
}
