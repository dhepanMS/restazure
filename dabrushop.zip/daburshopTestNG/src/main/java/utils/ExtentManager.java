package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {

	private static ExtentReports extent;

	public static ExtentReports getInstance() {
		if (extent == null) {
			
			  String reportPath = System.getProperty("user.dir") + "/test-output/report/ExtentReport.html";
			ExtentSparkReporter reporter = new ExtentSparkReporter(reportPath);
			reporter.config().setDocumentTitle("DaburShop Test Report");
			reporter.config().setReportName("Automation Test Results");

			extent = new ExtentReports();
			extent.attachReporter(reporter);
			extent.setSystemInfo("Project", "DaburShop");
			extent.setSystemInfo("Tester", "Dhepan");
			extent.setSystemInfo("Environment", "QA");
		}
		return extent;
	}
}
